//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vlamits3.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_OPTIONS                     101
#define IDB_SPLASH                      102
#define IDR_MAINFRAME                   128
#define IDR_VLAMITTYPE                  129
#define IDD_ERRORBOX                    204
#define IDD_SAVE                        205
#define IDD_LOAD                        206
#define IDD_YESNOABORT                  207
#define IDD_TEXTBOX                     208
#define IDD_SELECT_EPISODE              209
#define IDD_WAIT                        210
#define IDC_COMBO_DEVICES               1000
#define IDC_TEXT                        1003
#define IDC_ENAME                       1004
#define IDC_COMBO_GAMES                 1005
#define IDC_ETEXT                       1007
#define IDC_LIST1                       1008
#define IDM_BIP                         32771
#define IDM_START                       32772
#define IDM_STOP                        32773
#define IDM_OPTIONS                     32774
#define IDM_PAUSE                       32779
#define IDM_ZKEY                        32781
#define IDM_RESTART                     32782
#define IDM_SWITCHAPP                   32783
#define IDM_NEXT                        32784
#define IDM_GAMMA                       32785
#define IDM_SAVE                        32786
#define IDM_LOAD                        32787
#define IDM_HELP                        32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        211
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
